import 'package:ecommerce/model/api_response.dart';
import 'package:ecommerce/model/api_error.dart';
import 'package:ecommerce/model/user.dart';
import 'package:ecommerce/apiservice/apiIntegration.dart';
import 'dart:convert';

import 'package:http/http.dart' as http;

String _baseUrl = "https://www.grapheneassociates.in/grocery/";
Future<ApiResponse> authenticateUser(String username, String password) async {
  ApiResponse _apiResponse = new ApiResponse();

  try {
    final response = await http.post('${_baseUrl}api/login.php', body: {
      'username': username,
      'password': password,
    });

    switch (response.statusCode) {
      case 200:
        _apiResponse.Data = User.fromJson(json.decode(response.body));
        break;
      case 401:
        _apiResponse.ApiError = ApiError.fromJson(json.decode(response.body));
        break;
      default:
        _apiResponse.ApiError = ApiError.fromJson(json.decode(response.body));
        break;
    }
  } on Exception {
    _apiResponse.ApiError = ApiError(error: "Server error. Please retry");
  }
  return _apiResponse;
}
