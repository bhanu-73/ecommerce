class User {
  /*
  This class encapsulates the json response from the api
  {
      'userId': '1908789',
      'username': username,
      'name': 'Peter Clarke',
      'lastLogin': "23 March 2020 03:34 PM",
      'email': 'x7uytx@mundanecode.com'
  }
  */
  late String _id;
  late String _wallet;
  late String _name;
  late String _mobile;
  late String _email;

  // constructorUser(
  User(String id, String wallet, String name, String mobile, String email) {
    this._id = id;
    this._wallet = wallet;
    this._name = name;
    this._mobile = mobile;
    this._email = email;
  }

  // Properties
  String get id => _id;
  set id(String id) => _id = id;
  String get wallet => _wallet;
  set wallet(String wallet) => wallet = wallet;
  String get name => _name;
  set name(String name) => _name = name;
  String get mobile => _mobile;
  set mobile(String lastLogin) => _mobile = mobile;
  String get email => _email;
  set email(String email) => _email = email;

  // create the user object from json input
  User.fromJson(Map<String, dynamic> json) {
    _id = json['id'];
    _wallet = json['wallet'];
    _name = json['name'];
    _mobile = json['mobile'];
    _email = json['email'];
  }

  // exports to json
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['wallet'] = this._wallet;
    data['name'] = this._name;
    data['mobile'] = this._mobile;
    data['email'] = this._email;
    return data;
  }
}
